---
layout: post
title: Cayman Blog Theme
date: 2017-05-01 08:00:00
homepage: https://github.com/lorepirri/cayman-blog
download: https://github.com/lorepirri/cayman-blog/archive/master.zip
demo: https://lorepirri.github.io/cayman-blog/
author: Lorenzo Pirritano (@lorepirri)
thumbnail: thumbnail-cayman-blog-250.png
license: Creative Commons Attribution 1.0 International
license_link: https://github.com/lorepirri/cayman-blog/blob/master/LICENSE
---

Cayman Blog is a Jekyll theme for GitHub Pages. It is based on the nice Cayman theme, with blogging features added.
